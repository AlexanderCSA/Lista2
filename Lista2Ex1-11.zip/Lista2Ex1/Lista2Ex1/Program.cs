﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;

            Console.Write("Digite o primeiro valor: \n");
            valor1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o segundo valor: \n");
            valor2 = double.Parse(Console.ReadLine());

            if (valor1 < valor2)
            {
                Console.Write("O segundo valor é o maior\n");
            }
            else
            {
                Console.Write("O primeiro valor é o maior\n");
            }
        }
    }
}
