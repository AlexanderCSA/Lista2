﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex3P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n1;
            double n2;
            double n3;

            Console.Write("Digite o 1° Valor: ");
            n1 = double.Parse(Console.ReadLine());


            Console.Write("Digite o 2° Valor: ");
            n2 = double.Parse(Console.ReadLine());

            Console.Write("Digite o 3° Valor: ");
            n3 = double.Parse(Console.ReadLine());

            if (n1 == n2)
            {
                if (n1 == n3)
                {
                    Console.WriteLine("Os 3 valores são idênticos");
                }
                else
                {
                    if (n1 > n3)
                    {
                        Console.WriteLine("Os maiores valores são o 1° e o 2°");
                    }
                    else
                    {
                        Console.WriteLine("O Maior valor é o 3°");
                    }
                }
            }
            else
            {
                if (n1 == n3)
                {
                    if (n1 > n2)
                    {
                        Console.WriteLine("Os maiores valores são o 1° e o 3°");
                    }
                    else
                    {
                        Console.WriteLine("O maior valor é o 2°");
                    }
                }
                else
                {
                    if (n2 == n3)
                    {
                        if (n2 > n1)
                        {
                            Console.WriteLine("Os maiores valores são o 2° e o 3°");
                        }
                        else
                        {
                            Console.WriteLine("O maior valor é o 1°");
                        }
                    }
                    else
                    {
                        if (n1 > n2)
                        {
                            if (n1 > n3)
                            {
                                Console.WriteLine("O maior valor é o 1°");
                            }
                            else
                            {
                                Console.WriteLine("O maior valor é o 2°");
                            }
                        }
                        else
                        {
                            if (n2 > n3)
                            {
                                Console.WriteLine("O maior valor é o 2°");
                            }
                            else
                            {
                                Console.WriteLine("O maior valor é o 3°");
                            }
                        }
                    }
                }
            }
        }
    }
}
