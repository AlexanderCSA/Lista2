﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex5P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double h;
            double b;
            double area;

            Console.Write("Digite o valor da base em m: ");
            b = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da altura em m: ");
            h = double.Parse(Console.ReadLine());

            area = h * b;

            Console.Write("O valor da área do retângulo é {0}m²", area);

            if (area > 100)
            {
                Console.WriteLine(" ");
                Console.WriteLine("Terreno grande");
            }
            else
             {
                Console.WriteLine(" ");
                Console.WriteLine("Terreno Pequeno");
             }
        }
    }
}
