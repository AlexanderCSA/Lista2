﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex7P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double l1;
            double l2;
            double l3;

            Console.Write("Informe o 1º valor: ");
            l1 = double.Parse(Console.ReadLine());

            Console.Write("Informe o 2º valor: ");
            l2 = double.Parse(Console.ReadLine());

            Console.Write("Informe o 3º valor: ");
            l3 = double.Parse(Console.ReadLine());


            if ((l1 + l2) > l3)
            {
                if ((l2 + l3) > l1)
                {
                    if ((l1 + l3) > l2)
                    {
                        if (l1 == l2)
                        {
                            if (l2 == l3)
                            {
                                Console.WriteLine("Triângulo Equilatero");
                            }
                            else
                            {
                                Console.WriteLine("Triângulo Isósceles");
                            }
                        }
                        else
                        {
                            if (l1 == l3)
                            {
                                Console.WriteLine("Triângulo Isósceles");
                            }
                            else
                            {
                                if (l2 == l3)
                                {
                                    Console.WriteLine("Triângulo Isósceles");
                                }
                                else
                                {
                                    Console.WriteLine("Triângulo Escaleno");
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Não Formam um Triângulo");
                    }
                }
                else
                {
                    Console.WriteLine("Não Formam um Triângulo");
                }
            }
            else
            {
                Console.WriteLine("Não Formam um Triângulo");
            }
        }
    }
}
