﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex10P
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double np1;
            double np2;
            double media;

            Console.Write("Digite o valor da primeira nota: ");
            np1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da segunda nota: ");
            np2 = double.Parse(Console.ReadLine());

            media = (np1 + 2 * np2) / 3;

            if (media >= 5)
            {
                Console.WriteLine("Aprovado");
            }

             else
             {
                Console.WriteLine("Reprovado");
             }


        }
    }
}
